/*************************************************************************
 * Caio Vinicius Dadauto   7994808             Estrutura de Dados 2      *
 *                                             EP2                       *
 * Tabela de simbolos com arvore binaria                                 *
 * Programa baseado em:                                                  *
 *  http://algs4.cs.princeton.edu/32bst/BST.java.html                    *
 *                                                                       *
 *************************************************************************/

import java.util.NoSuchElementException;

public class BST<Key extends Comparable<Key>, Value> {
    private Node
        root;

    private class Node {
        private Key 
            key;         // Chave associada
        private Value 
            val;         // Valor associado
        private Node 
            left,        // Subarvore a esquerda
            right;       // Subarvore a direita
        private int 
            N;           // Numero de no´s na subarvore

        public Node(Key key, Value val, int N) {
            this.key = key;
            this.val = val;
            this.N   = N;
        }
    }

    // Verifica se a tabela de simbolos esta vazia
    public boolean isEmpty() {
        return size() == 0;
    }

    // Retorna o numero de no´s na tabela BST
    public int size() {
        return size(root);
    }

    // Retorna o numero de no´s na subarvore com root x
    private int size(Node x) {
        if (x == null) return 0;
        else return x.N;
    }

    // Verfica a existencia do no´s com chave key dada
    public boolean contains(Key key) {
        return get(key) != null;
    }

    // Retorna o valor associado a chave key dada, se a chave nao existir retorna null
    public Value get(Key key) {
        return get(root, key);
    }

    // Retorna valor associado a chave key na arvore com raiz x
    private Value get(Node x, Key key) {
        while(x != null) {
            int cmp = key.compareTo(x.key);
            if     (cmp < 0) x = x.left;
            else if(cmp > 0) x = x.right;
            else             return x.val;
        }

        return null;
    }

    // Insere um novo no´ a arvore, se a chave ja existir, atualiza-se o valor associado a essa chave
    public void put(Key key, Value val) {
        if(val == null){
            delete(key);
            return;
        }

        root = put(root, key, val);
        assert check();
    }

    // Funcao recursiva axiliar de put, recursao baseada na ordenacao crescente da esqueda para direita
    private Node put(Node x, Key key, Value val) {
        if(x == null)
            return new Node(key, val, 1);

        int cmp = key.compareTo(x.key);
        if     (cmp < 0) x.left  = put(x.left,  key, val);
        else if(cmp > 0) x.right = put(x.right, key, val);
        else             x.val   = val;

        x.N = 1 + size(x.left) + size(x.right);
        return x;
    }

    // Deleta o minimo de BST
    public void deleteMin() {
        if(isEmpty())
            throw new NoSuchElementException("Symbol table underflow");

        root = deleteMin(root);
        assert check();
    }

    // Funcao recursiva axiliar de deleteMin, recursao baseada na ordenacao crescente da esqueda para direita
    private Node deleteMin(Node x) {
        if(x.left == null)
            return x.right;

        x.left = deleteMin(x.left);
        x.N    = 1 + size(x.left) + size(x.right);
        return x;
    }

    // Deleta o maximo de BST
    public void deleteMax() {
        if(isEmpty())
            throw new NoSuchElementException("Symbol table underflow");

        root = deleteMax(root);
        assert check();
    }

    // Funcao recursiva axiliar de deleteMax, recursao baseada na ordenacao crescente da esqueda para direita
    private Node deleteMax(Node x) {
        if(x.right == null)
            return x.left;

        x.right = deleteMax(x.right);
        x.N     = 1 + size(x.left) + size(x.right);
        return x;
    }


    // Deleta uma chave arbitraria
    public void delete(Key key) {
        root = delete(root, key);
        assert check();
    }

    // Funcao recursiva axiliar de delete, recursao baseada na ordenacao crescente da esqueda para direita
    private Node delete(Node x, Key key) {
        if(x == null)
            return null;

        int cmp = key.compareTo(x.key);
        if     (cmp < 0) x.left  = delete(x.left,  key);
        else if(cmp > 0) x.right = delete(x.right, key);
        else { 
            if(x.right == null)
                return x.left;
            if(x.left  == null)
                return x.right;

            Node t  = x;
            x       = min(t.right);
            x.right = deleteMin(t.right);
            x.left  = t.left;
        } 
        x.N = 1 + size(x.left) + size(x.right);
        return x;
    } 


   /***********************************************************************
    *  Minimo, Maximo, Chao e Teto
    ***********************************************************************/
    public Key min() {
        if(isEmpty())
            return null;

        return min(root).key;
    } 

    private Node min(Node x) { 
        if(x.left == null)
            return x; 
        else
            return min(x.left); 
    }

    public Key max() {
        if(isEmpty())
            return null;

        return max(root).key;
    }

    private Node max(Node x) { 
        if(x.right == null)
            return x; 
        else
            return max(x.right); 
    }

    public Key floor(Key key) {
        Node x = floor(root, key);

        if(x == null)
            return null;
        else
            return x.key;
    } 

    private Node floor(Node x, Key key) {
        if(x == null)
            return null;

        int cmp = key.compareTo(x.key);
        if(cmp == 0)
            return x;
        if(cmp < 0)
            return floor(x.left, key);

        Node t = floor(x.right, key); 
        if(t != null)
            return t;
        else
            return x; 
    } 

    public Key ceiling(Key key) {
        Node x = ceiling(root, key);

        if(x == null)
            return null;
        else
            return x.key;
    }

    private Node ceiling(Node x, Key key) {
        if(x == null)
            return null;

        int cmp = key.compareTo(x.key);
        if(cmp == 0)
            return x;
        if(cmp > 0)
            return ceiling(x.right, key); 

        Node t = ceiling(x.left, key); 
        if(t != null)
            return t;
        else
            return x; 
    }

   /***********************************************************************
    *  Rank e selecao
    ***********************************************************************/
    public Key select(int k) {
        if (k < 0 || k >= size())
            return null;
        Node x = select(root, k);
        return x.key;
    }
 
    // Retorna a chave de rank k dado 
    private Node select(Node x, int k) {
        if(x == null)
            return null; 

        int t = size(x.left); 
        if     (t > k) return select(x.left,  k); 
        else if(t < k) return select(x.right, k - t - 1); 
        else           return x; 
    } 

    public int rank(Key key) {
        return rank(key, root);
    } 

    // Numero de no´s com chaves menores que key dado
    private int rank(Key key, Node x) {
        if(x == null)
            return 0; 

        int cmp = key.compareTo(x.key); 
        if     (cmp < 0) return rank(key, x.left); 
        else if(cmp > 0) return 1 + size(x.left) + rank(key, x.right); 
        else             return size(x.left); 
    } 

    public Iterable<Key> keys() {
        return keys(min(), max());
    }

    public Iterable<Key> keys(Key lo, Key hi) {
        Queue<Key> queue = new Queue<Key>();
        keys(root, queue, lo, hi);
        return queue;
    } 

    private void keys(Node x, Queue<Key> queue, Key lo, Key hi) { 
        if(x == null)
            return; 

        int cmplo = lo.compareTo(x.key); 
        int cmphi = hi.compareTo(x.key); 

        if(cmplo < 0)
            keys(x.left, queue, lo, hi); 
        if(cmplo <= 0 && cmphi >= 0)
            queue.enqueue(x.key); 
        if(cmphi > 0)
            keys(x.right, queue, lo, hi); 
    } 

    public int size(Key lo, Key hi) {
        if(lo.compareTo(hi) > 0)
            return 0;
        if(contains(hi))
            return rank(hi) - rank(lo) + 1;
        else
            return rank(hi) - rank(lo);
    }


    public int height() {
        return height(root);
    }

    private int height(Node x) {
        if(x == null)
            return -1;

        return 1 + Math.max(height(x.left), height(x.right));
    }

    public Iterable<Key> levelOrder() {
        Queue<Key> keys   = new Queue<Key>();
        Queue<Node> queue = new Queue<Node>();
        queue.enqueue(root);

        while(!queue.isEmpty()) {
            Node x = queue.dequeue();
            if(x == null)
                continue;

            keys.enqueue(x.key);
            queue.enqueue(x.left);
            queue.enqueue(x.right);
        }
        return keys;
    }

    private boolean check() {
        if(!isBST())            StdOut.println("Em ordem nao simetrica");
        if(!isSizeConsistent()) StdOut.println("Contagens de subarvores nao consistentes");
        if(!isRankConsistent()) StdOut.println("Ranks nao consistentes");
        return isBST() && isSizeConsistent() && isRankConsistent();
    }

    private boolean isBST() {
        return isBST(root, null, null);
    }

    private boolean isBST(Node x, Key min, Key max) {
        if(x == null)                                return true;
        if(min != null && x.key.compareTo(min) <= 0) return false;
        if(max != null && x.key.compareTo(max) >= 0) return false;

        return isBST(x.left, min, x.key) && isBST(x.right, x.key, max);
    } 

    private boolean isSizeConsistent() {
        return isSizeConsistent(root);
    }

    private boolean isSizeConsistent(Node x) {
        if(x == null)                               return true;
        if(x.N != size(x.left) + size(x.right) + 1) return false;

        return isSizeConsistent(x.left) && isSizeConsistent(x.right);
    } 

    private boolean isRankConsistent() {
        for (int i = 0; i < size(); i++)
            if (i != rank(select(i)))
                return false;

        for (Key key : keys())
            if (key.compareTo(select(rank(key))) != 0)
                return false;

        return true;
    }
}
