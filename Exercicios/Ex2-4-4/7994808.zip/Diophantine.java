public class Diophantine{
    long
        sum;

    public long getSum(){
        return this.sum;
    }
}
